'''This file will help you getting the values of Configuration Values saved in config Files and we can use them throughout the Project'''

import configparser
from datetime import datetime
import os
import json

now= datetime.now()
date_time = now.strftime("%m_%d_%Y_%H_%M_%S")

parentDir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ConfigPath= os.path.join(parentDir+'/config/config.json')

with open(ConfigPath,'r') as file:
    config = json.loads(file.read())

# VALUES
TestSummaryReport= parentDir+config['TestSummaryReport']+date_time+'.xls'
LogReport= parentDir+config['LogsFile']+date_time
InputDataSheet= parentDir+config['InputDataSheet']
TestcaseSheet=parentDir+config['TestCaseSheet']+".xls"
EmailTemplate= parentDir+config['EmailTemplate']
HTMLReport= parentDir+config['HTMLReport']+date_time+".html"
browserType = config['BrowsertType']

