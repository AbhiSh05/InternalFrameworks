import allure
from locators.locators import AidemyHomePage
from selenium_base.common_functions import *


class Aidemy:

    def __init__(self, driver):
        self.driver = driver

    @allure.step("Opening Aidemy website")
    def open_page(self):
        launch_url(self.driver,"https://aidemy.org/internal/")
        waitforPageLoad(self.driver)

    @allure.step("Clicking SignIn Button")
    def click_signin_button(self):
        element_click(self.driver,*AidemyHomePage.sign_in_button)
        time.sleep(10)

