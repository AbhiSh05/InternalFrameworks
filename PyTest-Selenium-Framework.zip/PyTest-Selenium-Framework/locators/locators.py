from selenium.webdriver.common.by import By

class AidemyHomePage:
    sign_in_button = (By.XPATH,'//*[@id="myBtn"]')