from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

def launch_url(driver,url):
    driver.get(url)
    driver.maximize_window()
    waitforPageLoad(driver)
    time.sleep(5)

def waitforPageLoad(driver):
    try:
        javaScript = "return document.readyState"
        result = driver.execute_script(javaScript)
        if(result!="complete"):
            waitforPageLoad()
    except Exception as e:
        print(e.args)
        print("Filed in wait for page Load Function")

def implicit_wait(driver):
    driver.implicitly_wait(10)

def waitForElementVisibility(driver,*element):
    try:
        WebDriverWait(driver,30).until(EC.presence_of_element_located(*element))
    except Exception as e:
        print(e.args)
        print("Method waitForElementVisiblity failed")

def waitForElementisClickable(driver,*element):
    try:
        WebDriverWait(driver,30).until(EC.element_to_be_clickable(*element))
    except Exception as e:
        print(e.args)
        print("Method waitForElementisClickable failed")

def waitForElementStaleness(driver,*element):
    try:
        WebDriverWait(driver,30).until(EC.staleness_of(*element))
    except Exception as e:
        print(e.args)
        print("Method waitForElementStaleness failed")

def check_selected(element):
    try:
        return element.is_selected()
    except Exception as e:
        print(e.args)
        print("Method is_selected failed")

def check_enabled(element):
    try:
        return element.is_enabled()
    except Exception as e:
        print(e.args)
        print("Method check_enabled failed")

def check_displayed(element):
    try:
        return element.is_displayed()
    except Exception as e:
        print(e.args)
        print("Method is_displayed failed")

def element_click(driver,*element):
    try:
        waitForElementVisibility(driver,*element)
        waitForElementisClickable(driver,*element)
        driver.find_element(*element).click()
    except Exception as e:
        print(e.args)
        print("Method element_click failed")

def get_text(element):
    try:
        return element.text
    except Exception as e:
        print(e.args)
        print("Method get_text failed")

