import os

os.system("pytest -v test_scripts/test_practice.py")