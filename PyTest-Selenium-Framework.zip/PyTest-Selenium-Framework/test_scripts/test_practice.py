import pytest
import allure
from page_objects.aidemy import Aidemy


@pytest.mark.usefixtures("setup")
class TestLogIn:

    @allure.title("Login with valid data test")
    @allure.description("This is test of login with valid data")
    def test_login_passed(self):
        aidemy_page = Aidemy(self.driver)
        aidemy_page.open_page()
        aidemy_page.click_signin_button()